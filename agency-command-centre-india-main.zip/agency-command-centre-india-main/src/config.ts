// Global app configuration
// Toggle demo mode to decouple Supabase and use static, in-memory data only
export const DEMO_MODE = true;
